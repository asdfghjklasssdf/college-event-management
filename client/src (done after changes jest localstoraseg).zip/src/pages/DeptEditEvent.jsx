import React, { useEffect, useState } from "react";
import axios from "axios";
import "./DeptEditEvent.css";
import { useParams } from "react-router-dom";

const DeptEditEvent = () => {
  const { id } = useParams();

  const [eventData, setEventData] = useState({});
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const res = await axios.get(`/api/events/${id}`);
        setEventData(res.data);
      } catch (err) {
        setError("Failed to load event details");
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id]);

  const handleChange = (e) => {
    setEventData({ ...eventData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    setMessage("");

    try {
      await axios.patch(`/api/events/edit/${id}`, eventData);
      setMessage("Event updated successfully 🎉");
    } catch (err) {
      setError("Update failed. Try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="loader">Loading event...</div>;

  return (
    <div className="edit-wrapper">
      <div className="edit-card">
        <h2>Edit Event</h2>
        <p className="subtitle">{eventData.eventName}</p>

        {message && <div className="alert success">{message}</div>}
        {error && <div className="alert danger">{error}</div>}

<form onSubmit={handleSubmit} className="form-grid">

  {/* Event Name */}
  <div className="form-group">
    <label>Event Name</label>
    <input
      name="eventName"
      value={eventData.eventName || ""}
      onChange={handleChange}
      required
    />
  </div>

  {/* Event Type */}
  <div className="form-group">
    <label>Event Type</label>
    <select
      name="eventType"
      value={eventData.eventType || ""}
      onChange={handleChange}
      required
    >
      <option value="">Select type</option>
      <option>Technical</option>
      <option>Cultural</option>
      <option>Sports</option>
      <option>Workshop</option>
      <option>Seminar</option>
      <option>Other</option>
    </select>
  </div>

  {/* Organizer */}
  <div className="form-group">
    <label>Organizer Name</label>
    <input
      name="organizerName"
      value={eventData.organizerName || ""}
      onChange={handleChange}
    />
  </div>

  {/* Department */}
  <div className="form-group">
    <label>Department</label>
    <input
      name="department"
      value={eventData.department || ""}
      onChange={handleChange}
      readOnly
    />
  </div>

  {/* Venue */}
  <div className="form-group">
    <label>Venue</label>
    <input
      name="venue"
      value={eventData.venue || ""}
      onChange={handleChange}
    />
  </div>

  {/* Description */}
  <div className="form-group full">
    <label>Description</label>
    <textarea
      name="eventDescription"
      value={eventData.eventDescription || ""}
      onChange={handleChange}
      rows={3}
    />
  </div>

  {/* Date / time */}
  <div className="form-group">
    <label>Date</label>
    <input
      type="date"
      name="eventDate"
      value={eventData.eventDate?.slice(0, 10) || ""}
      onChange={handleChange}
    />
  </div>

  <div className="form-group">
    <label>Start Time</label>
    <input
      type="time"
      name="eventTime"
      value={eventData.eventTime || ""}
      onChange={handleChange}
    />
  </div>

  <div className="form-group">
    <label>End Time</label>
    <input
      type="time"
      name="eventEndTime"
      value={eventData.eventEndTime || ""}
      onChange={handleChange}
    />
  </div>

  {/* Registration link */}
  <div className="form-group full">
    <label>Registration Link</label>
    <input
      name="registrationLink"
      value={eventData.registrationLink || ""}
      onChange={handleChange}
    />
  </div>

  {/* Max Participants */}
  <div className="form-group">
    <label>Max Participants</label>
    <input
      type="number"
      name="maxParticipants"
      value={eventData.maxParticipants || ""}
      onChange={handleChange}
      min="0"
    />
  </div>

  {/* Paid Event Toggle */}
  <div className="form-group">
    <label>
      <input
        type="checkbox"
        name="isPaid"
        checked={eventData.isPaid || false}
        onChange={(e) =>
          setEventData({ ...eventData, isPaid: e.target.checked })
        }
      />
      &nbsp; Is Paid Event?
    </label>
  </div>

  {/* Entry Fee */}
  {eventData.isPaid && (
    <div className="form-group">
      <label>Entry Fee</label>
      <input
        type="number"
        name="entryFee"
        value={eventData.entryFee || ""}
        onChange={handleChange}
      />
    </div>
  )}

  {/* Contact details */}
  <div className="form-group">
    <label>Contact Person</label>
    <input
      name="contactPerson"
      value={eventData.contactPerson || ""}
      onChange={handleChange}
    />
  </div>

  <div className="form-group">
    <label>Contact Email</label>
    <input
      name="contactEmail"
      value={eventData.contactEmail || ""}
      onChange={handleChange}
      required
    />
  </div>

  <div className="form-group">
    <label>Contact Number</label>
    <input
      name="contactNumber"
      value={eventData.contactNumber || ""}
      onChange={handleChange}
    />
  </div>

  {/* status */}
  <div className="form-group">
    <label>Status</label>
    <select
      name="status"
      value={eventData.status || "Upcoming"}
      onChange={handleChange}
    >
      <option>Upcoming</option>
      <option>Ongoing</option>
      <option>Completed</option>
    </select>
  </div>

  {/* Poster upload */}
  <div className="form-group full">
    <label>Poster Image</label>
    <input
      type="file"
      onChange={(e) =>
        setEventData({ ...eventData, posterImage: e.target.files[0] })
      }
    />
  </div>

  {/* Save button */}
  <button className="save-btn" type="submit" disabled={saving}>
    {saving ? "Saving..." : "Save Changes"}
  </button>
</form>

      </div>
    </div>
  );
};

export default DeptEditEvent;
