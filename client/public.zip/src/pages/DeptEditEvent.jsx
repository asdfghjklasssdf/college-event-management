import React, { useEffect, useState } from "react";
import axios from "axios";
import "./DeptEditEvent.css";
import { useParams } from "react-router-dom";

const DeptEditEvent = () => {
  const { id } = useParams();
  const [eventData, setEventData] = useState({});
  const [message, setMessage] = useState("");

  useEffect(() => {
    axios.get(`/api/events/${id}`).then((res) => setEventData(res.data));
  }, [id]);

  const handleChange = (e) => {
    setEventData({ ...eventData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await axios.patch(`/api/events/edit/${id}`, eventData);
    setMessage("Event Updated Successfully");
  };

  return (
    <div className="edit-container">
      <h1>Edit Event</h1>

      <form onSubmit={handleSubmit} className="edit-form">
        <input name="eventName" value={eventData.eventName || ""} onChange={handleChange} />
        <input name="eventType" value={eventData.eventType || ""} onChange={handleChange} />
        <textarea name="eventDescription" value={eventData.eventDescription || ""} onChange={handleChange} />
        <input type="date" name="eventDate" value={eventData.eventDate?.slice(0, 10) || ""} onChange={handleChange} />
        <input type="time" name="eventTime" value={eventData.eventTime || ""} onChange={handleChange} />
        <input type="time" name="eventEndTime" value={eventData.eventEndTime || ""} onChange={handleChange} />

        <button type="submit">Save Changes</button>

        {message && <p className="success">{message}</p>}
      </form>
    </div>
  );
};

export default DeptEditEvent;
