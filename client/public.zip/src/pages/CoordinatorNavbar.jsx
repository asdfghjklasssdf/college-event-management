import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Navbar.css"; // you can replace with custom CSS if needed

const DepartmentNavbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <nav className="navbar">
      <div className="nav-container">
        
        {/* LOGO / TITLE */}
        <Link to="/deptdashboard" className="nav-logo">
          <span>Panel</span>
        </Link>

        {/* Mobile Menu Button */}
        <button
          className="nav-toggle"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          ☰
        </button>

        {/* Navigation Links */}
        <div className={`nav-links ${menuOpen ? "open" : ""}`}>
          <Link to="/deptadd-event" className="nav-item">
            Add Event
          </Link>

          <Link to="/deptlist-event" className="nav-item">
            List Events
          </Link>

          <Link to="/deptbook-venue" className="nav-item">
            Book Venue
          </Link>

          <Link to="/deptdownloads" className="nav-item">
            Downloads
          </Link>

          <Link to="/dept/profile" className="nav-item">
            Downloads
          </Link>

          <Link to="/dept/notifications" className="nav-item">
            Downloads
          </Link>
                    
          <Link to="/dept/publish-results/:eventId" className="nav-item">
            Downloads
          </Link>

        <Link to="/dept/participants/select" className="nav-item">
  View Participants
</Link>

          {/* Logout */}
          <button
            className="logout-btn"
            onClick={() => {
              localStorage.clear();
              window.location.href = "/login";
            }}
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
};

export default DepartmentNavbar;
